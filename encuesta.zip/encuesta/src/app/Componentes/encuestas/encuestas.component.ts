import { Component, OnInit, ViewChild } from '@angular/core';
import { EncuestaService } from 'src/app/Service/encuesta.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Encuesta } from 'src/app/Model/encuesta';
@Component({
  selector: 'app-encuestas',
  templateUrl: './encuestas.component.html',
  styleUrls: ['./encuestas.component.css']
})
export class EncuestasComponent implements OnInit {
  displayedColumns: string[] = ['id', 'email', 'tipo', 'accion'];
  encuestas: Encuesta[] = [];
  @ViewChild(MatPaginator,{static:true}) paginator: MatPaginator;
  dsEncuestas: MatTableDataSource<Encuesta>;
  constructor(private service: EncuestaService) { 
    this.dsEncuestas = new MatTableDataSource<Encuesta>();
  }
  ngAfterViewInit() {
    this.dsEncuestas.paginator = this.paginator;
  }
  ngOnInit() {
    this.service.listarEncuestas().subscribe((result) =>{
      this.dsEncuestas.data=result;
      console.log(result);
    })
  }

}
