import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { EncuestaService } from 'src/app/Service/encuesta.service';
import { FormBuilder,FormGroup } from '@angular/forms';
import Swal from 'sweetalert2';
interface Encuesta {
  email: string;
  tipoCocacola: string;

}
interface TipoCocacola {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-encuesta-form',
  templateUrl: './encuesta-form.component.html',
  styleUrls: ['./encuesta-form.component.css']
})
export class EncuestaFormComponent implements OnInit {
  encuesta: FormGroup;
  bebidas: TipoCocacola[] = [
    {value: 'Light', viewValue: 'Light'},
    {value: 'Sin azúcar', viewValue: 'Sin azúcar'},
    {value: 'normal', viewValue: 'normal'},
    {value: 'no tomo', viewValue: 'no tomo'}
  ];
  ngOnInit() {
    this.encuesta = new FormGroup({
      email: new FormControl(''),
      tipoCocacola: new FormControl('')
    });
  }

  constructor(private service: EncuestaService) { }


  onSubmit(form: FormGroup) {
    console.log('Valid?', form.valid); // true or false
    console.log('Email', form.value.email);
    console.log('Message', form.value.tipoCocacola);
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: 'btn btn-success',
        cancelButton: 'btn btn-danger'
      },
      buttonsStyling: false
    })
    
    swalWithBootstrapButtons.fire({
      title: 'Seguro desea adicionar la respuesta?',
      text: "Los cambios no podran ser revertidos!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Si, adicionar!',
      cancelButtonText: 'No, cancelar!',
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        swalWithBootstrapButtons.fire(
          'Adicionando!',
          'Usted a enviado la respuesta correctamente.',
          'success'
        ).then((result)=>{
          this.service.addEncuestas(form.value).subscribe((res)=>{
            const Toast = Swal.mixin({
              toast: true,
              position: 'top-end',
              showConfirmButton: false,
              timer: 3000,
              timerProgressBar: true,
              didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
              }
            })
            
            Toast.fire({
              icon: 'success',
              title: `Usuario ${form.value.email} prefiere coca cola: ${form.value.tipoCocacola}`
            })
          })
        }
      )
       
      } else if (
        /* Read more about handling dismissals below */
        result.dismiss === Swal.DismissReason.cancel
      ) {
        swalWithBootstrapButtons.fire(
          'Cancelled',
          'Your imaginary file is safe :)',
          'error'
        )
      }
    })
   
  }
}
