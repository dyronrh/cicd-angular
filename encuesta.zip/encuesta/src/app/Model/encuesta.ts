export interface Encuesta {
     id?: string;
     email: string;
     tipoCocacola: string;
}
